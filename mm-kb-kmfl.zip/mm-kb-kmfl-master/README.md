#Myanmar Unicode Keyboards for Ubuntu

##Installation

```sh
$ make install
```

##Uninstallation

```sh
$ make uninstall
```

##Supported Languages

- Burmese (Myanmar3 Standard Layout and MyWin Layout)
- Shan
- Pa-Oh
- SgawKaren
